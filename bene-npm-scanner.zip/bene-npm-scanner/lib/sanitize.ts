// Copyright (c) 2024 Benedikt Pankratz
// Licensed under the Business Source License 1.1

import type { PackageInput, ScanRequest } from "./types";

// ─── Constants ────────────────────────────────────────────────────────────────

const MAX_PACKAGES = parseInt(process.env["MAX_PACKAGES_PER_REQUEST"] ?? "500", 10);

// npm package name spec: https://github.com/npm/validate-npm-package-name
// Scoped:     @scope/package
// Unscoped:   package-name
const NPM_NAME_REGEX = /^(?:@[a-z0-9_-][a-z0-9_.-]*\/)?[a-z0-9_-][a-z0-9_.-]*$/i;

// Semver-like: allows "1.2.3", "^1.0", "~2", "1.x", "*", "latest", etc.
// We're permissive here — OSV handles version resolution.
// We strictly block characters that could be used for injection.
const VERSION_SAFE_REGEX = /^[a-zA-Z0-9.*^~<>=| -]{1,64}$/;

// Max lengths to prevent DoS via oversized strings
const MAX_NAME_LENGTH = 214; // npm's own limit
const MAX_VERSION_LENGTH = 64;

// ─── Validation ───────────────────────────────────────────────────────────────

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

/**
 * Validate a single package name.
 * Does NOT allow path traversal, null bytes, or shell metacharacters.
 */
export function validatePackageName(name: unknown): ValidationResult {
  if (typeof name !== "string") {
    return { valid: false, error: "Package name must be a string" };
  }

  const trimmed = name.trim();

  if (trimmed.length === 0) {
    return { valid: false, error: "Package name cannot be empty" };
  }

  if (trimmed.length > MAX_NAME_LENGTH) {
    return { valid: false, error: `Package name exceeds maximum length of ${MAX_NAME_LENGTH}` };
  }

  // Block null bytes — they can bypass filters
  if (trimmed.includes("\0")) {
    return { valid: false, error: "Package name contains invalid characters" };
  }

  if (!NPM_NAME_REGEX.test(trimmed)) {
    return { valid: false, error: `Invalid package name: "${trimmed}"` };
  }

  return { valid: true };
}

/**
 * Validate a package version string.
 */
export function validateVersion(version: unknown): ValidationResult {
  if (typeof version !== "string") {
    return { valid: false, error: "Version must be a string" };
  }

  const trimmed = version.trim();

  if (trimmed.length === 0) {
    return { valid: false, error: "Version cannot be empty" };
  }

  if (trimmed.length > MAX_VERSION_LENGTH) {
    return { valid: false, error: "Version string is too long" };
  }

  if (trimmed.includes("\0")) {
    return { valid: false, error: "Version contains invalid characters" };
  }

  if (!VERSION_SAFE_REGEX.test(trimmed)) {
    return { valid: false, error: `Version "${trimmed}" contains unsafe characters` };
  }

  return { valid: true };
}

/**
 * Parse and validate a raw package.json or lock file input.
 * Accepts:
 *   - A JSON string (package.json or package-lock.json)
 *   - A plain object already parsed
 *
 * Returns a validated list of PackageInput items.
 * Throws a descriptive error string on any violation.
 */
export function parseAndValidateInput(rawInput: string): {
  packages: PackageInput[];
  warnings: string[];
} {
  // ── 1. Size guard (prevent DoS via huge payloads) ───────────────────────
  if (rawInput.length > 1_000_000) {
    throw new Error("Input is too large. Maximum size is 1MB.");
  }

  // ── 2. Parse JSON ────────────────────────────────────────────────────────
  let parsed: unknown;
  try {
    parsed = JSON.parse(rawInput);
  } catch {
    throw new Error("Invalid JSON. Please paste a valid package.json or lock file.");
  }

  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new Error("Expected a JSON object (package.json or package-lock.json).");
  }

  const obj = parsed as Record<string, unknown>;
  const warnings: string[] = [];
  const packages: PackageInput[] = [];
  const seen = new Set<string>();

  // ── 3. Detect format ─────────────────────────────────────────────────────
  const isLockV1 = typeof obj["lockfileVersion"] === "number" && obj["lockfileVersion"] === 1 && typeof obj["dependencies"] === "object";
  const isLockV2 = typeof obj["lockfileVersion"] === "number" && (obj["lockfileVersion"] === 2 || obj["lockfileVersion"] === 3) && typeof obj["packages"] === "object";

  if (isLockV2) {
    // package-lock.json v2/v3 — "packages" key
    const pkgMap = obj["packages"] as Record<string, unknown>;
    for (const [key, value] of Object.entries(pkgMap)) {
      // Skip the root package (empty string key or "node_modules/...")
      if (!key || !key.startsWith("node_modules/")) continue;

      const name = key.replace(/^node_modules\//, "").replace(/\/node_modules\//g, "/");
      if (typeof value !== "object" || value === null) continue;
      const version = (value as Record<string, unknown>)["version"];

      if (typeof version !== "string") continue;

      extractPackage(name, version, packages, seen, warnings);
    }
  } else if (isLockV1) {
    // package-lock.json v1 — "dependencies" key
    const deps = obj["dependencies"] as Record<string, unknown>;
    extractFromDepsV1(deps, packages, seen, warnings);
  } else {
    // Regular package.json — combine dependencies + devDependencies + peerDependencies
    const depFields = ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"];
    for (const field of depFields) {
      const deps = obj[field];
      if (typeof deps !== "object" || deps === null) continue;

      for (const [name, version] of Object.entries(deps as Record<string, unknown>)) {
        if (typeof version !== "string") continue;
        // Strip semver range prefix for OSV lookup
        const cleanVersion = version.replace(/^[^0-9]*/, "").split(" ")[0] ?? version;
        extractPackage(name, cleanVersion, packages, seen, warnings);
      }
    }
  }

  if (packages.length === 0) {
    throw new Error("No packages found. Make sure you pasted a valid package.json or package-lock.json.");
  }

  if (packages.length > MAX_PACKAGES) {
    warnings.push(`Truncated to ${MAX_PACKAGES} packages (input had more).`);
    packages.splice(MAX_PACKAGES);
  }

  return { packages, warnings };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractFromDepsV1(
  deps: Record<string, unknown>,
  packages: PackageInput[],
  seen: Set<string>,
  warnings: string[],
): void {
  for (const [name, value] of Object.entries(deps)) {
    if (typeof value !== "object" || value === null) continue;
    const v = (value as Record<string, unknown>)["version"];
    if (typeof v === "string") {
      extractPackage(name, v, packages, seen, warnings);
    }
    // Recurse nested dependencies
    const nested = (value as Record<string, unknown>)["dependencies"];
    if (typeof nested === "object" && nested !== null) {
      extractFromDepsV1(nested as Record<string, unknown>, packages, seen, warnings);
    }
  }
}

function extractPackage(
  name: string,
  version: string,
  packages: PackageInput[],
  seen: Set<string>,
  warnings: string[],
): void {
  const key = `${name}@${version}`;
  if (seen.has(key)) return;

  const nameValidation = validatePackageName(name);
  const versionValidation = validateVersion(version);

  if (!nameValidation.valid) {
    warnings.push(`Skipped "${name}": ${nameValidation.error}`);
    return;
  }

  if (!versionValidation.valid) {
    warnings.push(`Skipped "${name}@${version}": ${versionValidation.error}`);
    return;
  }

  seen.add(key);
  packages.push({ name: name.trim(), version: version.trim() });
}

/**
 * Validate an incoming API ScanRequest body.
 * Used when callers POST a pre-processed list (not raw JSON).
 */
export function validateScanRequest(body: unknown): ScanRequest {
  if (typeof body !== "object" || body === null) {
    throw new Error("Request body must be a JSON object.");
  }

  const obj = body as Record<string, unknown>;

  if (!Array.isArray(obj["packages"])) {
    throw new Error("'packages' must be an array.");
  }

  const packages: PackageInput[] = [];

  for (const item of obj["packages"] as unknown[]) {
    if (typeof item !== "object" || item === null) {
      throw new Error("Each package must be an object with 'name' and 'version'.");
    }

    const pkg = item as Record<string, unknown>;
    const nameResult = validatePackageName(pkg["name"]);
    const versionResult = validateVersion(pkg["version"]);

    if (!nameResult.valid) throw new Error(nameResult.error ?? "Invalid name");
    if (!versionResult.valid) throw new Error(versionResult.error ?? "Invalid version");

    packages.push({
      name: (pkg["name"] as string).trim(),
      version: (pkg["version"] as string).trim(),
    });
  }

  if (packages.length > MAX_PACKAGES) {
    throw new Error(`Too many packages. Maximum allowed is ${MAX_PACKAGES}.`);
  }

  return { packages };
}
