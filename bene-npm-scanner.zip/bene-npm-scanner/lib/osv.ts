// Copyright (c) 2024 Benedikt Pankratz
// Licensed under the Business Source License 1.1

import type {
  OsvBatchResult,
  OsvVulnerability,
  PackageResult,
  ScanReport,
  Severity,
  VulnerabilityEntry,
} from "@/lib/types";

const OSV_API      = "https://api.osv.dev/v1/querybatch";
const CHUNK_SIZE   = 100;
const TIMEOUT_MS   = 15_000;

const SEVERITY_ORDER: Record<Severity, number> = {
  CRITICAL: 5, HIGH: 4, MEDIUM: 3, LOW: 2, UNKNOWN: 1,
};

function parseCvssScore(vuln: OsvVulnerability): number | null {
  const raw = vuln.database_specific?.cvss;
  if (!raw) return null;
  const m = /(\d+\.\d+)/.exec(raw);
  if (!m?.[1]) return null;
  const n = parseFloat(m[1]);
  return isNaN(n) ? null : n;
}

function parseSeverity(vuln: OsvVulnerability): Severity {
  const dbSev = vuln.database_specific?.severity?.toUpperCase();
  if (dbSev && dbSev in SEVERITY_ORDER) return dbSev as Severity;

  const score = parseCvssScore(vuln);
  if (score !== null) {
    if (score >= 9.0) return "CRITICAL";
    if (score >= 7.0) return "HIGH";
    if (score >= 4.0) return "MEDIUM";
    if (score >= 0.1) return "LOW";
  }

  for (const s of vuln.severity ?? []) {
    const n = parseFloat(s.score);
    if (!isNaN(n)) {
      if (n >= 9.0) return "CRITICAL";
      if (n >= 7.0) return "HIGH";
      if (n >= 4.0) return "MEDIUM";
      return "LOW";
    }
    const u = s.score.toUpperCase();
    if (u in SEVERITY_ORDER) return u as Severity;
  }
  return "UNKNOWN";
}

function highestSeverity(severities: Severity[]): Severity {
  return severities.reduce<Severity>(
    (best, cur) => SEVERITY_ORDER[cur] > SEVERITY_ORDER[best] ? cur : best,
    "UNKNOWN"
  );
}

function extractFixedVersion(vuln: OsvVulnerability): string | null {
  for (const affected of vuln.affected ?? []) {
    for (const range of affected.ranges ?? []) {
      for (const event of range.events) {
        if (event.fixed) return event.fixed;
      }
    }
  }
  return null;
}

function mapVuln(vuln: OsvVulnerability): VulnerabilityEntry {
  const score = parseCvssScore(vuln);
  return {
    id:          vuln.id,
    aliases:     vuln.aliases ?? [],
    summary:     vuln.summary ?? "No summary available",
    details:     vuln.details ?? "",
    severity:    parseSeverity(vuln),
    cvssScore:   score !== null ? score.toFixed(1) : null,
    cweIds:      vuln.database_specific?.cwe_ids ?? [],
    fixedIn:     extractFixedVersion(vuln),
    references:  (vuln.references ?? [])
      .filter((r) => typeof r.url === "string" && r.url.startsWith("https://"))
      .map((r) => ({ type: r.type, url: r.url })),
    publishedAt: vuln.published ?? null,
  };
}

export interface PackageInput {
  name:    string;
  version: string;
  isDev:   boolean;
}

export async function scanPackages(packages: PackageInput[]): Promise<ScanReport> {
  if (packages.length === 0) return emptyReport();

  const queries = packages.map((pkg) => ({
    package: { name: pkg.name, ecosystem: "npm" as const },
    version: pkg.version,
  }));

  const chunks: (typeof queries)[] = [];
  for (let i = 0; i < queries.length; i += CHUNK_SIZE) {
    chunks.push(queries.slice(i, i + CHUNK_SIZE));
  }

  const allResults: Array<{ vulns?: OsvVulnerability[] }> = [];

  for (const chunk of chunks) {
    const ctrl    = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(OSV_API, {
        method:  "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent":   "bene-npm-scanner/1.0 (github.com/Beneking102/bene-npm-scanner)",
        },
        body:   JSON.stringify({ queries: chunk }),
        signal: ctrl.signal,
      });
      if (!res.ok) throw new Error(`OSV API ${res.status}`);
      const data = await res.json() as OsvBatchResult;
      allResults.push(...(data.results ?? []));
    } finally {
      clearTimeout(timeout);
    }
  }

  const packageResults: PackageResult[] = packages.map((pkg, i) => {
    const vulns = (allResults[i]?.vulns ?? []).map(mapVuln);
    return {
      name:            pkg.name,
      version:         pkg.version,
      isDev:           pkg.isDev,
      vulnerabilities: vulns,
      highestSeverity: highestSeverity(vulns.map((v) => v.severity)),
    };
  });

  const counts = { critical: 0, high: 0, medium: 0, low: 0, unknown: 0 };
  for (const pkg of packageResults) {
    for (const v of pkg.vulnerabilities) {
      counts[v.severity.toLowerCase() as keyof typeof counts]++;
    }
  }

  return {
    scannedAt:     new Date().toISOString(),
    totalPackages: packages.length,
    affectedCount: packageResults.filter((p) => p.vulnerabilities.length > 0).length,
    counts,
    packages:      packageResults,
  };
}

function emptyReport(): ScanReport {
  return {
    scannedAt:     new Date().toISOString(),
    totalPackages: 0,
    affectedCount: 0,
    counts:        { critical: 0, high: 0, medium: 0, low: 0, unknown: 0 },
    packages:      [],
  };
}
